-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 17, 2018 at 04:03 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbwebsitedemo`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblactor_tblmovie`
--

CREATE TABLE IF NOT EXISTS `tblactor_tblmovie` (
  `actorid` int(11) NOT NULL,
  `movieid` int(11) NOT NULL,
  KEY `actorid` (`actorid`),
  KEY `movieid` (`movieid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblactor_tblmovie`
--

INSERT INTO `tblactor_tblmovie` (`actorid`, `movieid`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbleactor`
--

CREATE TABLE IF NOT EXISTS `tbleactor` (
  `actorid` int(11) NOT NULL AUTO_INCREMENT,
  `actname` varchar(30) NOT NULL,
  `actsex` varchar(10) NOT NULL,
  `actdob` date NOT NULL,
  `actbio` text,
  PRIMARY KEY (`actorid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbleactor`
--

INSERT INTO `tbleactor` (`actorid`, `actname`, `actsex`, `actdob`, `actbio`) VALUES
(1, 'Salman Kan', 'Male', '1965-12-27', 'Handsome and Bhaijaan of Bollywood'),
(2, 'akshay kumar', 'male', '0000-00-00', 'verygoodactor'),
(3, 'amir khan', 'male', '2018-07-17', 'verygood'),
(4, 'xyz', 'female', '2018-07-17', 'ssf'),
(5, 'abc', 'male', '2018-07-17', 'goodactor');

-- --------------------------------------------------------

--
-- Table structure for table `tblmovie`
--

CREATE TABLE IF NOT EXISTS `tblmovie` (
  `movieid` int(11) NOT NULL AUTO_INCREMENT,
  `moviename` varchar(30) NOT NULL,
  `movieYOR` varchar(30) NOT NULL,
  `movieplot` varchar(30) NOT NULL,
  `movieposter` text NOT NULL,
  PRIMARY KEY (`movieid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tblmovie`
--

INSERT INTO `tblmovie` (`movieid`, `moviename`, `movieYOR`, `movieplot`, `movieposter`) VALUES
(1, 'Bajarangi Bhaijaan', '2015', 'Drama and Action', 'a.jpg'),
(2, 'sultan', '2016', 'fdsfsfs', 'a.jpg'),
(3, 'TigerZindaHai', '2017', 'dramaandaction', 'b.jpg'),
(4, 'natrang', '2011', 'drama', 'a.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tblproducer`
--

CREATE TABLE IF NOT EXISTS `tblproducer` (
  `prodid` int(11) NOT NULL AUTO_INCREMENT,
  `prodname` varchar(30) NOT NULL,
  `prodsex` varchar(10) NOT NULL,
  `proddob` date NOT NULL,
  `prodbio` text NOT NULL,
  `movieid` int(11) NOT NULL,
  PRIMARY KEY (`prodid`),
  KEY `movieid` (`movieid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tblproducer`
--

INSERT INTO `tblproducer` (`prodid`, `prodname`, `prodsex`, `proddob`, `prodbio`, `movieid`) VALUES
(1, 'Kabir Kan', 'male', '2018-07-02', 'very good producer', 1),
(4, 'karan johar', 'male', '2018-07-17', 'good actor', 2),
(5, 'xyz', 'female', '2018-07-17', 'good', 4);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblactor_tblmovie`
--
ALTER TABLE `tblactor_tblmovie`
  ADD CONSTRAINT `tblactor_tblmovie_ibfk_1` FOREIGN KEY (`actorid`) REFERENCES `tbleactor` (`actorid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tblactor_tblmovie_ibfk_2` FOREIGN KEY (`movieid`) REFERENCES `tblmovie` (`movieid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblproducer`
--
ALTER TABLE `tblproducer`
  ADD CONSTRAINT `tblproducer_ibfk_1` FOREIGN KEY (`movieid`) REFERENCES `tblmovie` (`movieid`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
