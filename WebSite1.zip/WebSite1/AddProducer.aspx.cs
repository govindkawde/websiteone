﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddProducer : System.Web.UI.Page
{
    myClass m = new myClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        DropDownList1.Items.Add("--select--");
        m.filldropdown(DropDownList1, "select * from tblmovie", "moviename");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Label r1 = new Label();
        m.filllabel(r1, "select * from tblmovie where moviename='" + DropDownList1.SelectedItem.Text + "'", "movieid");
        if(m.dml("insert into tblproducer(prodname,prodsex,proddob,prodbio,movieid)values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + DateTime.Now.ToString("yyyy-MM-dd") + "','" + TextBox3.Text + "','" +r1.Text+"')"))
        {
            Response.Write("<script>alert('Producer Successfully added.');</script>");
            emptytext();
        }
       
    }
    public void emptytext()
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";

    }
}