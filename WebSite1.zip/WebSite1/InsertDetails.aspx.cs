﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class InsertDetails : System.Web.UI.Page
{
    myClass m = new myClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        DropDownList1.Items.Add("--select--");
        m.filldropdown(DropDownList1, "select * from tbleactor", "actname");
        DropDownList2.Items.Add("--select--");
        m.filldropdown(DropDownList2, "select * from tblproducer", "prodname");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Label r1 = new Label();
        Label r2 = new Label();
        m.filllabel(r1, "select * from tblproducer where prodname='" + DropDownList2.SelectedItem.Text + "'", "prodid");
        m.filllabel(r1, "select * from tbleactor where actname='" + DropDownList1.SelectedItem.Text + "'", "actorid");
        String path = Server.MapPath("photos");
    FileUpload1.SaveAs(path + "//" + FileUpload1.FileName);
       if(m.dml("insert into tblmovie(moviename,movieYOR,movieplot,movieposter)values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','"  + FileUpload1.FileName +"')"))
        {
            Response.Write("<script>alert('Movie Successfully added.');</script>");
            emptytext();
        }
       

    }
public void emptytext()
{
    TextBox1.Text = "";
    TextBox2.Text = "";
    TextBox3.Text = "";
   
}
}