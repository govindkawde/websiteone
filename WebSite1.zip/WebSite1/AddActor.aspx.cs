﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddActor : System.Web.UI.Page
{
    myClass m = new myClass();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (m.dml("insert into tbleactor(actname,actsex,actdob,actbio)values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + DateTime.Now.ToString("yyyy-MM-dd") + "','" + TextBox3.Text + "')"))
        {
            Response.Write("<script>alert('Actor Successfully added.');</script>");
            emptytext();
        }
   
    }
    public void emptytext()
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";

    }
}