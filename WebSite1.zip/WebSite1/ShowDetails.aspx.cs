﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ShowDetails : System.Web.UI.Page
{
    myClass m = new myClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        m.filllistView(ListView1, "select * from tblmovie,tbleactor,tblactor_tblmovie,tblproducer where tblmovie.movieid=tblactor_tblmovie.movieid and tbleactor.actorid=tblactor_tblmovie.actorid and tblmovie.movieid=tblproducer.movieid");
    }
}