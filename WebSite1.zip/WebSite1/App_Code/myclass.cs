﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
using System.Web.UI.WebControls;
using System.Data;

/// <summary>
/// Summary description for myClass
/// </summary>
public class myClass
{
    MySqlConnection con = new MySqlConnection(@"Server=localhost;Uid=root;Pwd=;Database=dbwebsitedemo");
    MySqlCommand com;
    MySqlDataReader dr;
    MySqlDataAdapter adr;
    public myClass()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public Boolean dml(String qry)
    {
        try
        {
            con.Open();
            com = new MySqlCommand(qry, con);
            com.ExecuteNonQuery();
            con.Close();
            return true;

        }
        catch (Exception e)
        {
            con.Close();
            return false;
        }
    }
    public Boolean exists(String qry)
    {
        try
        {
            con.Open();
            com = new MySqlCommand(qry, con);
            dr = com.ExecuteReader();
            if (dr.HasRows)
            {
                con.Close();
                return true;
            }
            else
            {
                con.Close();
                return false;
            }
        }
        catch (Exception e)
        {
            con.Close();
            return false;
        }
    }
    public void filllistView(ListView l, String qry)
    {
        con.Open();
        com = new MySqlCommand(qry, con);
        adr = new MySqlDataAdapter(com);
        DataSet ds = new DataSet();
        adr.Fill(ds);
        l.DataSource = ds;
        l.DataBind();
        con.Close();
    }
   
    public void filllabel(Label lb, String qry, String value)
    {
        con.Open();
        com = new MySqlCommand(qry, con);
        dr = com.ExecuteReader();
        if (dr.Read())
        {
            lb.Text = dr[value].ToString();
        }
        con.Close();
    }

    

    public void filldropdown(DropDownList ddlist, String qry, String val)
    {
        try
        {
            con.Open();
            com = new MySqlCommand(qry, con);
            dr = com.ExecuteReader();
            while (dr.Read())
            {
                ddlist.Items.Add(dr[val].ToString());
            }
            con.Close();
        }
        catch (Exception ex)
        {
            con.Close();

        }
    }
    public void filltextbox(TextBox t1, String qry, String value)
    {
        con.Open();
        com = new MySqlCommand(qry, con);
        dr = com.ExecuteReader();
        if (dr.Read())
        {
            t1.Text = dr[value].ToString();
        }
        con.Close();
    }
   

}