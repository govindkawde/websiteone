﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class EditMovie : System.Web.UI.Page
{
    myClass m = new myClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Label r = new Label();
            r.Text = Request.QueryString["id"];
            m.filltextbox(TextBox1, "select * from tblmovie where movieid='" + r.Text + "'", "moviename");
            m.filltextbox(TextBox2, "select * from tblmovie where movieid='" + r.Text + "'", "movieYOR");
            m.filltextbox(TextBox3, "select * from tblmovie where movieid='" + r.Text + "'", "movieplot");

        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Label r1 = new Label();
        r1.Text = Request.QueryString["id"];
        String path = Server.MapPath("photos");
        FileUpload1.SaveAs(path + "//" + FileUpload1.FileName);
        m.dml("update tblmovie set movieposter='" + FileUpload1.FileName + "',moviename='" + TextBox1.Text + "',movieYOR='" + TextBox2.Text + "',movieplot='"+TextBox3.Text+"' where movieid='" + r1.Text + "'");

        Response.Redirect("showmedicine.aspx");
    }
}